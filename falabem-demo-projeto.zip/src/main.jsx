import React from "react";
import ReactDOM from "react-dom/client";
import FalaBemDemo from "./FalaBemDemo.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <FalaBemDemo />
  </React.StrictMode>
);
